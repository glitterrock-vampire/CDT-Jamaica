#if defined(OPENSSL_NO_ASM)
# include "./asn1t_no-asm.h"
#else
# include "./asn1t_asm.h"
#endif
